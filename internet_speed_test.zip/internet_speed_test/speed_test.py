import argparse
import time
from statistics import mean

import requests


REQUESTS_COUNT = 10
TIMEOUT_SECONDS = 60


def measure(url: str) -> None:
    durations = []
    total_bytes = 0
    total_elapsed = 0.0
    successful = 0

    print(f"URL: {url}")
    print(f"Starting {REQUESTS_COUNT} sequential requests...\n")

    for i in range(1, REQUESTS_COUNT + 1):
        start = time.perf_counter()

        try:
            response = requests.get(url, timeout=TIMEOUT_SECONDS)
            response.raise_for_status()
            content = response.content  # Read the entire response body.

            elapsed = time.perf_counter() - start
            downloaded = len(content)

            durations.append(elapsed)
            total_bytes += downloaded
            total_elapsed += elapsed
            successful += 1

            print(
                f"Request {i:02d}: {elapsed:.3f} sec | "
                f"{downloaded / 1024 / 1024:.2f} MiB"
            )

        except requests.RequestException as error:
            elapsed = time.perf_counter() - start
            total_elapsed += elapsed
            print(f"Request {i:02d}: FAILED ({error})")

    print("\n--- Results ---")
    print(f"Successful requests: {successful}/{REQUESTS_COUNT}")

    if successful:
        avg_time = mean(durations)
        speed_mib_s = total_bytes / (1024 * 1024) / total_elapsed if total_elapsed else 0

        print(f"Average request time: {avg_time:.3f} sec")
        print(f"Total downloaded: {total_bytes / 1024 / 1024:.2f} MiB")
        print(f"Average download speed: {speed_mib_s:.2f} MiB/s")
    else:
        print("No successful requests. Check the URL and your internet connection.")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Measure download speed by making 10 sequential HTTP requests."
    )
    parser.add_argument("url", help="URL of the file to download")
    args = parser.parse_args()

    measure(args.url)


if __name__ == "__main__":
    main()
