# Internet Speed Test

A simple Python console script that downloads the same resource 10 times sequentially and measures request duration, total downloaded data, and average download speed.

## Requirements

- Python 3.9+
- pip

## Installation

```bash
python -m pip install -r requirements.txt
```

## Usage

```bash
python speed_test.py "https://example.com/file"
```

Replace the URL with a link to a large file (for example, an image or archive).

## What it measures

- **Average request time** — arithmetic mean of successful request durations.
- **Total downloaded** — sum of the response body sizes for successful requests.
- **Average download speed** — total downloaded data divided by total elapsed time for all attempts.

Speed is displayed in **MiB/s** (1 MiB = 1,048,576 bytes). Requests are performed sequentially; each response body is fully read before the next request begins.

Failed requests are reported and the script continues with the remaining attempts. A 60-second timeout is applied to each request.
